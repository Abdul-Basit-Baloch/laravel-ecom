<?php

namespace App\Http\Controllers;

use App\Models\ProductAttr;
use Illuminate\Http\Request;

class ProductAttrController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ProductAttr  $productAttr
     * @return \Illuminate\Http\Response
     */
    public function show(ProductAttr $productAttr)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ProductAttr  $productAttr
     * @return \Illuminate\Http\Response
     */
    public function edit(ProductAttr $productAttr)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ProductAttr  $productAttr
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProductAttr $productAttr)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ProductAttr  $productAttr
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductAttr $productAttr)
    {
        //
    }
}
